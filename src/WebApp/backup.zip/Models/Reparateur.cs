﻿namespace Pitstop.WebApp.Models
{
    public class Reparateur
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}
