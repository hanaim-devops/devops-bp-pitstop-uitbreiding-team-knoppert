﻿namespace Pitstop.WebApp.Models;

public class BusinessRuleViolation
{
    public string ErrorMessage { get; set; }
}