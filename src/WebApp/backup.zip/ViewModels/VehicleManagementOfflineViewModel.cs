﻿namespace Pitstop.WebApp.ViewModels;

public class VehicleManagementOfflineViewModel
{
}