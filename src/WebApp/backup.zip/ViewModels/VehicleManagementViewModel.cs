﻿namespace Pitstop.WebApp.ViewModels;

public class VehicleManagementViewModel
{
    public IEnumerable<Vehicle> Vehicles { get; set; }
}