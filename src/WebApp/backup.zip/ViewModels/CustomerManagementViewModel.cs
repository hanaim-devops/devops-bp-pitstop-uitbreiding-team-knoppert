﻿namespace Pitstop.WebApp.ViewModels;

public class CustomerManagementViewModel
{
    public IEnumerable<Customer> Customers { get; set; }
}