﻿namespace Pitstop.WebApp.ViewModels
{
    public class WorkshopManagementOfflineViewModel
    {
    }
}
