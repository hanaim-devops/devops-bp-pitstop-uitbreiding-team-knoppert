﻿namespace Pitstop.WebApp.ViewModels;

public class VehicleManagementDetailsViewModel
{
    public Vehicle Vehicle { get; set; }
    public string Owner { get; set; }
}