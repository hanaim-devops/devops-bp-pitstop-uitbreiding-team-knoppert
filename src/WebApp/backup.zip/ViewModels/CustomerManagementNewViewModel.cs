﻿namespace Pitstop.WebApp.ViewModels;

public class CustomerManagementNewViewModel
{
    public Customer Customer { get; set; }
}