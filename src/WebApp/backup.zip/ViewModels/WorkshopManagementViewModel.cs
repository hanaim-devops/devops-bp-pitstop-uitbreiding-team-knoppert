﻿namespace Pitstop.WebApp.ViewModels;

public class WorkshopManagementViewModel
{
    public DateTime Date { get; set; }
    public List<MaintenanceJob> MaintenanceJobs { get; set; }
}