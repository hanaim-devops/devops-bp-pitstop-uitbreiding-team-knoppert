﻿namespace Pitstop.WebApp.ViewModels;

public class CustomerManagementDetailsViewModel
{
    public Customer Customer { get; set; }
}