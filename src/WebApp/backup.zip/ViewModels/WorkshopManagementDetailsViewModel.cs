﻿namespace Pitstop.WebApp.ViewModels;

public class WorkshopManagementDetailsViewModel
{
    public DateTime Date { get; set; }
    public MaintenanceJob MaintenanceJob { get; set; }
}